package pt.ulisboa.tecnico.sec;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.fail;

public class ByzantineTest {
    private NodeManager manager = null;
    @Before
    public void setUp(){
        manager = new NodeManager();
        manager.createNode("127.0.0.1", 1380, "ledger1.cer");
        manager.createNode("127.0.0.1", 1381, "ledger2.cer");
        manager.createNode("127.0.0.1", 1382, "ledger3.cer");
        manager.createNode("127.0.0.1", 1383, "ledger4.cer");
        try {
            Wallet.loadKeys(System.getProperty("user.dir") + "/src/main/resources/" + "client1" + "/", "client1");
        }catch(Exception e){
            fail();
        }
    }

    @After
    public void tearDown(){
        manager = null;
    }

    @Test
    public void RunRequestAllFine(){
        Request request = new Request(Opcode.CREATE_ACCOUNT);
        boolean writeResult = manager.broadcastWrite(request);
        assertEquals(true, writeResult);

    }

}
