package pt.ulisboa.tecnico.sec;

import org.junit.After;
import org.junit.Before;

public class ByzantineTest {
    @Before
    public void setUp(){

    }

    @After
    public void tearDown(){

    }

}
