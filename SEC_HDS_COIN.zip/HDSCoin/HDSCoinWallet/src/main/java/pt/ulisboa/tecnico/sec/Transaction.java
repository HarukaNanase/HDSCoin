package pt.ulisboa.tecnico.sec;

public class Transaction {
    private Account source;
    private Account destination;
    private int value;
}
